﻿// Controllers/FractionController.cs
using Microsoft.AspNetCore.Mvc;
using FractionApp.Models;
using FractionApp.Services;
using System.Collections.Generic;
using System.IO;

namespace FractionApp.Controllers
{
    public class FractionController : Controller
    {
        private readonly IFractionService _fractionService;

        public FractionController(IFractionService fractionService)
        {
            _fractionService = fractionService;
        }

        // Головна сторінка дробів
        public IActionResult Index()
        {
            return View();
        }

        // Метод для обробки розрахунків дробів
        [HttpPost]
        public IActionResult Calculate(int numerator1, int denominator1, int numerator2, int denominator2, string operation)
        {
            var fraction1 = new Fraction(numerator1, denominator1);
            var fraction2 = new Fraction(numerator2, denominator2);
            Fraction resultFraction = null;
            decimal resultDecimal = 0;

            switch (operation)
            {
                case "Add":
                    resultFraction = _fractionService.Add(fraction1, fraction2);
                    break;
                case "Subtract":
                    resultFraction = _fractionService.Subtract(fraction1, fraction2);
                    break;
                case "Multiply":
                    resultFraction = _fractionService.Multiply(fraction1, fraction2);
                    break;
                case "Divide":
                    resultFraction = _fractionService.Divide(fraction1, fraction2);
                    break;
                case "Simplify":
                    resultFraction = _fractionService.Simplify(fraction1);
                    break;
            }

            // Скорочення результату
            if (resultFraction != null)
            {
                resultFraction = resultFraction.Simplify();
                resultDecimal = _fractionService.ToDecimal(resultFraction);
            }

            ViewBag.ResultFraction = resultFraction; // Скорочений дріб
            ViewBag.ResultDecimal = resultDecimal;   // Десятковий дріб
            return View("Index");
        }

        // Метод для завантаження дробів з файлу
        [HttpGet]
        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    string line;
                    List<Fraction> fractions = new List<Fraction>();

                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(new[] { '+', '^' });
                        if (parts.Length == 2 &&
                            int.TryParse(parts[0].Trim(), out int numerator) &&
                            int.TryParse(parts[1].Trim(), out int denominator))
                        {
                            fractions.Add(new Fraction(numerator, denominator));
                        }
                    }

                    // Обчислення суми дробів
                    var sumFraction = _fractionService.Sum(fractions);

                    // Збережіть завантажені дроби та суму в ViewBag
                    ViewBag.LoadedFractions = fractions;
                    ViewBag.SumFraction = sumFraction;
                }
            }
            return View("Upload");
        }

    }
}
