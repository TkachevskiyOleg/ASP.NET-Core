﻿using Microsoft.AspNetCore.Mvc;
using Car_1.Models;
using System.Collections.Generic;
using System.IO;

namespace Car_1.Controllers
{
    public class CarController : Controller
    {
        private static List<Car> _cars = new List<Car>();
        private const string FilePath = "Cars.txt"; 

        public IActionResult Index()
        {
            return View(_cars);
        }

        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddCar(string name, string color, string manufacturer, int year, double engineVolume)
        {
            // Create a new car instance
            var car = new Car
            {
                Name = name,
                Color = color,
                Manufacturer = manufacturer,
                Year = year,
                EngineVolume = engineVolume
            };

            // Add car to the list
            _cars.Add(car);

            // Save car to file
            SaveCarToFile(car);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        // Check for empty lines
                        if (string.IsNullOrWhiteSpace(line))
                        {
                            continue; // Skip empty lines
                        }

                        // Split the line into fields
                        var parts = line.Split(new[] { ',' }, System.StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length == 5 &&
                            int.TryParse(parts[3].Trim(), out int year) &&
                            double.TryParse(parts[4].Trim(), out double engineVolume))
                        {
                            // Create a new car and add it to the list
                            var car = new Car
                            {
                                Name = parts[0].Trim(),
                                Color = parts[1].Trim(),
                                Manufacturer = parts[2].Trim(),
                                Year = year,
                                EngineVolume = engineVolume
                            };

                            _cars.Add(car);
                            SaveCarToFile(car); // Save to file as well
                        }
                    }
                }
            }

            return RedirectToAction("Index"); // Redirect back to the list after upload
        }

        private void SaveCarToFile(Car car)
        {
            using (var writer = new StreamWriter(FilePath, true)) // Append to file
            {
                writer.WriteLine($"{car.Name},{car.Color},{car.Manufacturer},{car.Year},{car.EngineVolume}");
            }
        }
    }
}
