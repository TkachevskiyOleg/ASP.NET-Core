﻿// Models/Fraction.cs
using System;

namespace FractionApp.Models
{
    public class Fraction
    {
        public int Numerator { get; set; }
        public int Denominator { get; set; }

        public Fraction(int numerator, int denominator)
        {
            if (denominator == 0)
                throw new ArgumentException("Denominator cannot be zero.");

            Numerator = numerator;
            Denominator = denominator;
        }

        // Метод для скорочення дробу
        public Fraction Simplify()
        {
            int gcd = GCD(Numerator, Denominator);
            return new Fraction(Numerator / gcd, Denominator / gcd);
        }

        // Додавання дробів
        public Fraction Add(Fraction other)
        {
            int newNumerator = (Numerator * other.Denominator) + (other.Numerator * Denominator);
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        // Віднімання дробів
        public Fraction Subtract(Fraction other)
        {
            int newNumerator = (Numerator * other.Denominator) - (other.Numerator * Denominator);
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        // Множення дробів
        public Fraction Multiply(Fraction other)
        {
            int newNumerator = Numerator * other.Numerator;
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        // Ділення дробів
        public Fraction Divide(Fraction other)
        {
            if (other.Numerator == 0)
                throw new ArgumentException("Cannot divide by zero.");

            int newNumerator = Numerator * other.Denominator;
            int newDenominator = Denominator * other.Numerator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        // Перетворення на десятковий дріб
        public decimal ToDecimal()
        {
            return (decimal)Numerator / Denominator;
        }

        // Метод для знаходження найбільшого спільного дільника (НСД)
        private static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int remainder = a % b;
                a = b;
                b = remainder;
            }
            return Math.Abs(a);
        }

        // Метод для перетворення дробу в рядок
        public override string ToString()
        {
            return $"{Numerator}/{Denominator}";
        }
    }
}
