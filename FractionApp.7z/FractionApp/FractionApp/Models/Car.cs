﻿// Models/Car.cs
namespace Car_1.Models
{
    public class Car
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public string Manufacturer { get; set; }
        public int Year { get; set; }
        public double EngineVolume { get; set; }

        public Car(string name, string color, string manufacturer, int year, double engineVolume)
        {
            Name = name;
            Color = color;
            Manufacturer = manufacturer;
            Year = year;
            EngineVolume = engineVolume;
        }

        public Car() { }

        // Метод для виведення інформації про автомобіль
        public override string ToString()
        {
            return $"{Name} ({Color}) - {Manufacturer}, {Year}, Engine Volume: {EngineVolume}L";
        }

        // Метод для збереження інформації в файл
        public void SaveToFile(string filePath)
        {
            using (var writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(ToString());
            }
        }
    }
}
