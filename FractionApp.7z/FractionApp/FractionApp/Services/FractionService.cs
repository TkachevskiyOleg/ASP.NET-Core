﻿using System;
using System.Collections.Generic;
using System.IO;
using FractionApp.Models;
using Microsoft.AspNetCore.Http;

namespace FractionApp.Services
{
    public class FractionService : IFractionService
    {
        public Fraction Add(Fraction a, Fraction b) => a.Add(b);
        public Fraction Subtract(Fraction a, Fraction b) => a.Subtract(b);
        public Fraction Multiply(Fraction a, Fraction b) => a.Multiply(b);
        public Fraction Divide(Fraction a, Fraction b) => a.Divide(b);
        public Fraction Simplify(Fraction fraction) => fraction.Simplify();
        public decimal ToDecimal(Fraction fraction) => fraction.ToDecimal();

        // Реалізація методу для завантаження дробів з файлу
        public List<Fraction> LoadFractionsFromFile(IFormFile file)
        {
            var fractions = new List<Fraction>();
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine()?.Trim();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    // Визначення типу роздільника
                    string[] parts;
                    if (line.Contains("+"))
                    {
                        parts = line.Split("+", StringSplitOptions.RemoveEmptyEntries);
                    }
                    else if (line.Contains("^"))
                    {
                        parts = line.Split("^", StringSplitOptions.RemoveEmptyEntries);
                    }
                    else
                    {
                        throw new FormatException("Unsupported file format.");
                    }

                    if (parts.Length == 2 && int.TryParse(parts[0], out int numerator) && int.TryParse(parts[1], out int denominator))
                    {
                        fractions.Add(new Fraction(numerator, denominator));
                    }
                }
            }
            return fractions;
        }
        public Fraction Sum(IEnumerable<Fraction> fractions)
        {
            Fraction total = new Fraction(0, 1); // Початкова сума
            foreach (var fraction in fractions)
            {
                total = Add(total, fraction); // Додаємо дроби
            }
            return total.Simplify(); // Повертаємо скорочену суму
        }
    }
}
