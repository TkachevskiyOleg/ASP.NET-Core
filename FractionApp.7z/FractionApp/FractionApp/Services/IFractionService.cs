﻿// Services/IFractionService.cs
using FractionApp.Models;

namespace FractionApp.Services
{
    public interface IFractionService
    {
        Fraction Add(Fraction a, Fraction b);
        Fraction Subtract(Fraction a, Fraction b);
        Fraction Multiply(Fraction a, Fraction b);
        Fraction Divide(Fraction a, Fraction b);
        Fraction Simplify(Fraction fraction);
        decimal ToDecimal(Fraction fraction);
        Fraction Sum(IEnumerable<Fraction> fractions);
        List<Fraction> LoadFractionsFromFile(IFormFile file);
    }
}
